const express = require('express');
const mysql = require('mysql2');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cookieParser());
app.use(cors({ credentials: true, origin: 'http://localhost:5173' }));

const db = mysql.createPool({ 
    host: 'localhost', 
    user: 'root', 
    password: '', 
    database: 'uas_uangku' 
});

const SECRET = "UAS_UANGKU_RAHASIA";

const verifyToken = (req, res, next) => {
    const token = req.cookies.token;
    if (!token) return res.status(401).json({ msg: "Silakan login" });
    jwt.verify(token, SECRET, (err, decoded) => {
        if (err) return res.status(403).json({ msg: "Token tidak valid" });
        req.userId = decoded.id;
        next();
    });
};

app.post('/api/register', async (req, res) => {
    const { username, password } = req.body;
    const hash = await bcrypt.hash(password, 10);
    db.query('INSERT INTO users (username, password) VALUES (?,?)', [username, hash], (err) => {
        if (err) return res.status(500).json({ msg: "Gagal daftar" });
        res.json({ msg: "Berhasil Daftar" });
    });
});

app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    db.query('SELECT * FROM users WHERE username = ?', [username], async (err, result) => {
        if (result.length > 0 && await bcrypt.compare(password, result[0].password)) {
            const token = jwt.sign({ id: result[0].id }, SECRET, { expiresIn: '1d' });
            res.cookie('token', token, { httpOnly: true, maxAge: 24 * 60 * 60 * 1000 });
            res.json({ msg: "Login Berhasil", username: result[0].username });
        } else {
            res.status(401).json({ msg: "Username/Password Salah" });
        }
    });
});

app.get('/api/expenses', verifyToken, (req, res) => {
    db.query('SELECT * FROM expenses WHERE user_id = ?', [req.userId], (err, data) => res.json(data));
});

app.post('/api/expenses', verifyToken, (req, res) => {
    const { item_name, amount, category } = req.body;
    db.query('INSERT INTO expenses (item_name, amount, category, user_id) VALUES (?,?,?,?)', 
    [item_name, amount, category, req.userId], () => res.json({ msg: "Tersimpan" }));
});

app.listen(5000, () => console.log("Server running on port 5000"));